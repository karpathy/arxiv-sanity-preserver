
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.19.3'
version = '1.19.3'
full_version = '1.19.3'
git_revision = '5010177cfcab1efff8cf5b8eeee093491ae4bc8b'
release = True

if not release:
    version = full_version
